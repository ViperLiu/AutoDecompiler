#coding=utf-8
import os
import sys

if len(sys.argv) != 3:
	print ("以關鍵字列表(以逗號分隔)檔案之關鍵字搜尋工作目錄內的所有檔案\n")
	print ("請輸入正確參數，格式為：")
	print ("keywordSearch.py [workDirPath] [keyDirFile]\n")
	print ("[workDirPath] 欲搜尋的工作目錄路徑，如 C:\\Temp\\SearchDir\\")
	print ("[keyDirFile]  搜尋使用的關鍵字列表檔案路徑位置，如 C:\\Temp\\key.txt")
	sys.exit()

workDirPath = sys.argv[1]
keyDirFile = sys.argv[2]
extList = [".exe", ".so", ".png", ".jpg", ".image"];

with open(keyDirFile, 'r', encoding = "utf-8", errors = "ignore") as k:
	keys = k.read().split(',')
	for keyword in keys:
		hitCount = 0
		hitFile = 0
		keyword = keyword.strip()
		print ("=== Search keyword \"" + keyword +"\" [START] ===")
		for dirPath, dirNames, fileNames in os.walk(workDirPath):
			for f in fileNames:
				if (os.path.splitext(f)[-1] in extList):
					continue
				searchFile = os.path.join(dirPath, f)
				with open(searchFile, 'r', encoding = "utf-8", errors = "ignore") as fo:
					printFirstLine = True
					for (num, line) in enumerate(fo):
						try:
							index = line.find(keyword)
							if(index != -1):
								if (printFirstLine):
									print ("## Found \"" + keyword + "\"" + " in \"" + searchFile + "\"")
									printFirstLine = False
								#lineHighlight = line.replace(keyword, "\'" + keyword + "\'").strip()
								lineHighlight = line.strip()
								if len(lineHighlight) > 100 and index < 40:
									lineHighlight = lineHighlight[:index+50]
								elif len(lineHighlight) > 100 and index > 40:
									lineHighlight = lineHighlight[index-20:index+20]
								print ("Line", str(num+1) + ":", lineHighlight)
								hitCount += line.count(keyword)
						except: #UnicodeEncodeError, UnicodeDecodeError:
							continue		
					if(printFirstLine == False):
						hitFile += 1
						print()
		print ("=== Search keyword \"" + keyword +"\" [END] ("+ str(hitCount) + " hits in " + str(hitFile) + " files) ===\n")